<?php

class UsuarioModel {
    public $id;
    public $login;
    public $senha;
    
}

