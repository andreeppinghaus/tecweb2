<?php
session_start();
require_once("Banco.php");

if (! isset($_SESSION["autenticado"])){
    
    header('Location: https://aula-php-andre-eppinghaus.000webhostapp.com/2021-1/aula-quarta/');
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    
    <title>Incluir</title>
  </head>
  <body>
     
     <div class="container">
         
     
    <h1>Inclusão de produtos</h1>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->
    
    <form action="gravarProduto.php" method="post">
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Nome</label>
          <input type="text" class="form-control" id="exampleFormControlInput1" name="nome">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Descrição</label>
          <textarea class="form-control" id="exampleFormControlTextarea1" name="descricao" rows="3"></textarea>
        </div>
        
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Valor</label>
          <input type="number" class="form-control" id="exampleFormControlInput1" 
          step="0.2" min="0" name="valor">
        </div>
        
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Desconto</label>
          <input type="number" class="form-control" id="exampleFormControlInput1" 
          step="0.2" min="0" name="desconto">
        </div>
        <div class="mb-3">
          <label for="exampleFormControlInput1" class="form-label">Código do Produto</label>
          <input type="text" class="form-control" id="exampleFormControlInput1" 
            name="codigo_produto">
        </div>
        
        <input type="submit" class="btn btn-success" value="Salvar">
        
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<link href="//cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    
 <script src="//cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

<script>
    
    $(document).ready( function () {
        // console.log("funcionou");
    $('#myTable').DataTable();
} );
</script>

  </body>
</html>
