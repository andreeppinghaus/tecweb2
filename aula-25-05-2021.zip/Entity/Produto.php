<?php


class Produto {
    
    private $id, $nome, $descricao, $valor, $desconto, $codigo_produto, $data_criacao;
    
    function __construct($data) {
        $this-> hidrator($data);
    }
    
    function hidrator($data) {
        
        if (isset($data['id'])){
            $this->id = $data['id'];
        }
        
        if (isset($data['nome'])){
            $this->nome = $data['nome'];
        }
        if (isset($data['descricao'])){
            $this->descricao = $data['descricao'];
        }
        if (isset($data['valor'])){
            $this->valor = $data['valor'];
        }
        if (isset($data['desconto'])){
            $this->desconto = $data['desconto'];
        }
        if (isset($data['codigo_produto'])){
            $this->codigo_produto = $data['codigo_produto'];
        }
        
    }
    
    function getNome() {
        return $this->nome;
    }
    function getDescricao() {
        return $this->descricao;
    }
    
    function getSQLIncluir() {
        
        $sql = "insert into produto (nome, descricao, valor, desconto, codigo_produto) 
        values (".$this->nome.",".$this->descricao.",".$this->valor.",".$this->desconto.",".
        $this->codigo_produto.")";
        return $sql;
    }
    
}