<?php
session_start();
require_once("Banco.php");
require_once("Entity/Produto.php");

if (! isset($_SESSION["autenticado"])){
    
    header('Location: https://aula-php-andre-eppinghaus.000webhostapp.com/2021-1/aula-quarta/');
}

// var_dump($_POST);

$pdo = new Banco();

$produto = new Produto($_POST);

echo "<p>SQL</p>".$produto->getSQLIncluir();

?>

