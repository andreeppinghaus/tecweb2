<html>
    <head>
        <title>Aula 10 - 04/05/2021</title>
    </head>
    <body>
        <form action="valida.php">
            <label>Email</label>
            <input type="email" name="email">
            <br><br>
            <label>Senha</label>
            <input type="text" name="senha">
            <br><br>
            <input type="submit" >
        </form>
    </body>
</html>